import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {JSDOM} from 'jsdom';
import {defaultState,zones,finalQuestions} from '../data.js';
test('DOM flow: languages, discovery, all missions, resume, results, retake and field settings',async()=>{
 const dom=new JSDOM(fs.readFileSync(new URL('../index.html',import.meta.url),'utf8'),{url:'https://example.github.io/jurassic-english-vr/'});const {window}=dom;const initial=defaultState();initial.settings.field=true;window.localStorage.setItem('jurassic-english-vr-v1',JSON.stringify(initial));
 const old={window:globalThis.window,document:globalThis.document,localStorage:globalThis.localStorage,addEventListener:globalThis.addEventListener,setInterval:globalThis.setInterval,setTimeout:globalThis.setTimeout};Object.assign(globalThis,{window,document:window.document,localStorage:window.localStorage,addEventListener:window.addEventListener.bind(window),setInterval:()=>0,setTimeout:()=>0});
 window.HTMLDialogElement.prototype.showModal=function(){this.open=true;};window.HTMLDialogElement.prototype.close=function(){this.open=false;this.dispatchEvent(new window.Event('close'));};const $=id=>window.document.getElementById(id),click=id=>{assert.ok($(id),`missing #${id}`);$(id).click();};const saved=()=>JSON.parse(window.localStorage.getItem('jurassic-english-vr-v1'));
 try{await import('../script.js');click('lang');assert.equal(window.document.documentElement.lang,'es');assert.equal($('start').textContent,'INICIAR AVENTURA');click('start');await Promise.resolve();await Promise.resolve();assert.equal($('game').hidden,false);click('introGo');click('observe');assert.ok(saved().discovered.includes('triceratops'));assert.equal(saved().xp,15);click('cardClose');
  for(let zi=0;zi<4;zi++){
   click('mission');const qs=zones[zi].questions;
   // An incorrect answer explains the rule and awards no XP.
   if(zi===0){const before=saved().xp;$('panelBody').querySelector('[data-answer="0"]').click();assert.ok($('panelBody').textContent.includes('Usamos is'));assert.equal(saved().xp,before);}
   for(const q of qs){if(q.type==='text'){$('written').value=q.answer;$('answerForm').dispatchEvent(new window.Event('submit',{cancelable:true}));}else $('panelBody').querySelector(`[data-answer="${q.answer}"]`).click();assert.ok($('nextQuestion'));click('nextQuestion');}
   assert.ok(saved().completed.includes(zi));click('nextZone');assert.equal(saved().zone,zi+1);
  }
  click('mission');for(let i=0;i<finalQuestions.length;i++){const q=finalQuestions[i];const answer=i===0?0:q.answer;$('panelBody').querySelector(`[data-answer="${answer}"]`).click();click('nextQuestion');}
  assert.equal(saved().result.score,24);assert.equal($('panelTitle').textContent,'CONGRATULATIONS, EXPLORER!');assert.ok($('panelBody').textContent.includes('24/25'));$('studentName').value='José Explorador';$('studentName').dispatchEvent(new window.Event('input'));assert.equal(saved().name,'José Explorador');
  const xp=saved().xp;click('retake');for(const q of finalQuestions){$('panelBody').querySelector(`[data-answer="${q.answer}"]`).click();click('nextQuestion');}assert.equal(saved().result.score,25);assert.equal(saved().xp,xp+10); // only previously missed answer can award XP
  click('closePanel');click('settings');assert.equal($('field').checked,true);$('quality').value='low';click('applySettings');assert.equal(saved().settings.quality,'low');click('journal');click('amber');assert.ok(saved().secret);assert.ok(saved().xp>=xp+35);
  // Verify readable storage data holds complete results for a new page visit.
  const roundTrip=JSON.parse(JSON.stringify(saved()));assert.equal(Object.keys(roundTrip.finalAnswers).length,25);assert.equal(roundTrip.completed.length,5);
 }finally{Object.assign(globalThis,old);dom.window.close();}
});
